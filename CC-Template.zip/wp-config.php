<?php
define( 'WP_CACHE', true );
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'knurhssu_wp194' );

/** MySQL database username */
define( 'DB_USER', 'knurhssu_wp194' );

/** MySQL database password */
define( 'DB_PASSWORD', '..1S7B1fn[Vp.G' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'mwfp9pd9fztwcv4mldngypwod7hvk345i9nnqbh2umbzg7j2tgsoevezwembtzso' );
define( 'SECURE_AUTH_KEY',  '4iclfpgsimjyhnblnydm1clkhni8rbm9xpnbhizm5liiezhyidm7iyemqipxmgih' );
define( 'LOGGED_IN_KEY',    'bevfhfkvhbcrazskmxgdxsvsoacian4q2z14zupv7ppukbs74dqe7atw3h6rfyhf' );
define( 'NONCE_KEY',        '5ksygxdgsooutojob4eyfv4aadkbyfp5pjc1cdauyzmze8pkvzttzcumiddfi9ex' );
define( 'AUTH_SALT',        'ty2jsrcewucvhlrxwyxqivdaehgvmfgtgxnuaxcwcr46d3x3vcmwvjxu60bs4guq' );
define( 'SECURE_AUTH_SALT', 'afux2jnak5qfal6tr1cu7mflp4znopy7p51ykaumvslbwmjk1ehnwf9gd8o65yqq' );
define( 'LOGGED_IN_SALT',   'l1mgpsz5ypy7v6oktiwpge43mu7mkoerhfwargedvuva0nrbhej8mzbcga0tkt8r' );
define( 'NONCE_SALT',       'xn2sqo1bifctmi4behnasaerictlj3waxbl4ddu1qptbrtjbvdpsu0kycusgqqw5' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpsw_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
